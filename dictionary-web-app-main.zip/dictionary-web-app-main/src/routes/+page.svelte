<script lang="ts">
    import Status from "../lib/components/StatusComponent/Status.svelte";
    // import type { PageData } from './$types';
    // export let data: PageData
    // import { themeStore } from "$lib/stores/themeStore";
    // import {fontStore} from "$lib/stores/fontStore";

    // const {themeCookie, fontCookie} = data

    // if(themeCookie) {
    //     themeStore.set(themeCookie)
    // }

    // if(fontCookie) {
    //     fontStore.set(fontCookie)
    // }
    
</script>

<main>
    <Status status='welcome'/>
</main >
