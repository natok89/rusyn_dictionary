
<div
	class="
        h-[18px] w-[18px] 
        border-2
        border-t-purple border-r-transparent border-b-purple border-l-purple 
        border-solid rounded-full
        animate-spin"

        data-testid='loading-spinner'
/>

