import 'vitest-canvas-mock';
